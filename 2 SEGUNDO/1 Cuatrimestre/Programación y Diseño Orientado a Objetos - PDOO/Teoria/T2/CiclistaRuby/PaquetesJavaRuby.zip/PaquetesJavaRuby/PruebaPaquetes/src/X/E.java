/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package X;
import X.Y.*;
import X.Z.V.*;
 
/**
 *
 * @author ana
 */
public class E {
    private C c;  
    private B b;
    private X.Z.D d;
    private X.Y.U.A a; 
//   private  F f;
}
