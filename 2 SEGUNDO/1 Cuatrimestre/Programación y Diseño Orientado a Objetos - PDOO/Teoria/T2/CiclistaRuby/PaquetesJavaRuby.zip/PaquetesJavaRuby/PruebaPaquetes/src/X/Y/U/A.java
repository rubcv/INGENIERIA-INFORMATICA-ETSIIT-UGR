/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package X.Y.U; 
import X.Z.V.B;
 
 

/**
 *
 * @author ana
 */
public class A {
    private X.E e;
    private X.Y.C c;
    private X.Z.D d;
    private B b;
    
}
