/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package X.Y;
 
/**
 *
 * @author ana
 */
public class C {
    private  X.E e;
    private X.Z.D d;
    private  X.Z.V.B b;
    private X.Y.U.A a;
}
