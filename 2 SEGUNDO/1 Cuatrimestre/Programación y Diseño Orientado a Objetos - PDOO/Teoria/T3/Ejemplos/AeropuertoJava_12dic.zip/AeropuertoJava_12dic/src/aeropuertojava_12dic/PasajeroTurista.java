
package aeropuertojava_12dic;


public class PasajeroTurista extends Pasajero{
          
  @Override
  void embarcar(){
    hacerCola();
    seguirProtocoloDeSeguridad();
    System.out.println("Accedo al vuelo "+numVuelo);
  }
  
  void hacerCola(){
    System.out.println("Hago cola");
  }

}
