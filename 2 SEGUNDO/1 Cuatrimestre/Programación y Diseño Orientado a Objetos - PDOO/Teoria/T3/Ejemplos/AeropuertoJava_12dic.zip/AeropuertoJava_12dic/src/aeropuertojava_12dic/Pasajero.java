
package aeropuertojava_12dic;


class Pasajero {

    private String numVuelo;
    private String pasaporte;
    private static final int KILOSPERMITIDOS=20;
    
    Pasajero(String pasaporte, String numVuelo){
        this.pasaporte = pasaporte;
        this.numVuelo = numVuelo;
    }
    
    String getNumVuelo(){
        return numVuelo;
    }
   
    @Override
    String toString(){
        return "Soy el pasajero con pasaporte "+pasaporte+" del vuelo "+numVuelo;
    }
  
    void dejarCocheEnParking(){
        System.out.println("He dejado el coche en el parking");
    }
  
    void facturar(int kgs){
        if(kgs<=KILOSPERMITIDOS)
            System.out.println("He podido facturar");
        else
            System.out.println("No he podido facturar");
    }
 
    void embarcar(){
        seguirProtocoloDeSeguridad();
        System.out.println("Accedo al vuelo "+numVuelo);
    }
  
    private void seguirProtocoloDeSeguridad(){
        System.out.println ("Paso el control de seguridad con mi pasaporte "+pasaporte);
    }
}
