
package aeropuertojava_12dic;

public class Main {

    
    public static void main(String[] args) {
        //PASO 1: Presta atención a los fallos de compilación. ¿A qué se deben? Trata de resolverlos
        
        //PASO 2: Implementa los métodos que quedan sin implementar en PasajeroBusiness

        //PASO 3: Descomenta el código siguiente y ejecútalo

        /**
        PasajeroTurista turista1 = new PasajeroTurista("pasaporteturista1", "IB2345");
        PasajeroBusiness vip1 = new PasajeroBusiness("pasaportevip1", "IB2345", "tarjetaoro134");
        
        System.out.println(turista1.toString());
        turista1.dejarCocheEnParking();
        turista1.facturar(30);
        turista1.embarcar();
        
        System.out.println("***********************************");
        
        System.out.println(vip1.toString());
        vip1.dejarCocheEnParking();
        vip1.accederASalaVip();
        vip1.facturar(30);
        vip1.embarcar();
        */

        //PASO 4: Incluye el código del menor al cargo como hicimos en Ruby

        
        
    }
    
}
