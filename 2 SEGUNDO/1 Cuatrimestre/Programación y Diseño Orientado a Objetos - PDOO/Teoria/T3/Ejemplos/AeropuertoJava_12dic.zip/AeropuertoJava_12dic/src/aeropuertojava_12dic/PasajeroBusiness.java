
package aeropuertojava_12dic;

class PasajeroBusiness extends Pasajero{

    String numeroTarjetaBusiness;
  
    PasajeroBusiness(String pasaporte, String numVuelo, String tarjeta){
        super(pasaporte,numVuelo);
        numeroTarjetaBusiness = tarjeta;
    }
  
    void trasladoAlAeropuerto(){
      System.out.println("Me llevan al aeropuerto");
    }

    void dejarCocheEnParking(){
      //Implementar el método
    }

    void accederASalaVip(){
      System.out.println("Descanso en sala VIP donde tengo acceso a comida y prensa");
    }

    void facturar(int kgs){
      //Implementar el método
    }
}
