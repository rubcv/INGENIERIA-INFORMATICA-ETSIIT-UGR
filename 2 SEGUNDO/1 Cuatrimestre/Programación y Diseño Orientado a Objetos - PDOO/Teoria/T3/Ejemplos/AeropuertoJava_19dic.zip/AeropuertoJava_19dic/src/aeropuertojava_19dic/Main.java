
package aeropuertojava_19dic;

public class Main {

    
    public static void main(String[] args) {
        //PRUEBAS EN CLASE
        
    }
    
}
