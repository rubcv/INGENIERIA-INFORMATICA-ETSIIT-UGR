
package aeropuertojava_19dic;


public class PasajeroTurista extends Pasajero{

    public PasajeroTurista(String pasaporte, String numVuelo) {
        super(pasaporte, numVuelo);
    }
   
    @Override
    void facturar(int kgs){
        if(kgs<=KILOSPERMITIDOS)
            System.out.println("He podido facturar");
        else
            System.out.println("No he podido facturar");
    }
               
    @Override
    void embarcar(){
      hacerCola();
      super.embarcar();
    }

    void hacerCola(){
      System.out.println("Hago cola");
    }

}
