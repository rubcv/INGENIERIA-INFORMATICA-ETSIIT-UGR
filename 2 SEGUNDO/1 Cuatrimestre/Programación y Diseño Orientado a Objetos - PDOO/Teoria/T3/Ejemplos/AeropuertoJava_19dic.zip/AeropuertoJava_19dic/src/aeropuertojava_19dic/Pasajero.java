
package aeropuertojava_19dic;


abstract class Pasajero {

    protected String numVuelo;
    protected String pasaporte;
    protected static final int KILOSPERMITIDOS=20;
    
    Pasajero(String pasaporte, String numVuelo){
        this.pasaporte = pasaporte;
        this.numVuelo = numVuelo;
    }
    
    String getNumVuelo(){
        return numVuelo;
    }
    
    String getPasaporte(){
        return numVuelo;
    }
   
    @Override
    public String toString(){
        return "Soy el pasajero con pasaporte "+pasaporte+" del vuelo "+numVuelo;
    }
  
    void dejarCocheEnParking(){
        System.out.println("He dejado el coche en el parking");
    }
  
    abstract void facturar(int kgs);
 
    void embarcar(){
        seguirProtocoloDeSeguridad();
        System.out.println("Accedo al vuelo "+numVuelo);
    }
  
    void seguirProtocoloDeSeguridad(){
        System.out.println ("Paso el control de seguridad con mi pasaporte "+pasaporte);
    }
}
