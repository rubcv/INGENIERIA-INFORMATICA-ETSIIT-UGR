
package aeropuertojava_19dic;

class PasajeroBusiness extends Pasajero{

    String numeroTarjetaBusiness;
  
    PasajeroBusiness(String pasaporte, String numVuelo, String tarjeta){
        super(pasaporte,numVuelo);
        numeroTarjetaBusiness = tarjeta;
    }
  
    void trasladoAlAeropuerto(){
      System.out.println("Me llevan al aeropuerto");
    }

    void dejarCocheEnParking(){
      dejarCocheEnParking();
      System.out.println("...y además me lo vigilan");
    }

    void accederASalaVip(){
      System.out.println("Descanso en sala VIP donde tengo acceso a comida y prensa");
    }

    void facturar(int kgs){
        if(kgs<=2*KILOSPERMITIDOS)
            System.out.println("He podido facturar");
        else
            System.out.println("No he podido facturar");
    }
}
