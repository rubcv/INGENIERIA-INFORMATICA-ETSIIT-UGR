
require_relative "pasajero_turista"
require_relative "pasajero_business"



#PASO 1: Implementa los métodos que quedan sin implementar en las clases PasajeroBusiness y PasajeroTurista


#PASO 2: Descomenta el código siguiente y ejecútalo

#turista1 = PasajeroTurista.new("pasaporteturista1", "IB2345")
#vip1 = PasajeroBusiness.new("pasaportevip1", "IB2345", "tarjetaoro134")
#
#puts turista1.to_s
#turista1.dejarCocheEnParking
#turista1.facturar(30)
#turista1.embarcar
#
#puts "***********************************"
#
#puts vip1.to_s
#vip1.dejarCocheEnParking
#vip1.accederASalaVip
#vip1.facturar(30)
#vip1.embarcar

#PASO 3: Incluimos una nueva asociación: un Pasajero puede llevar a otro pasajero menor a su cargo.
#Hacemos los cambios en el initialize y en el to_s. También en embarcar para que sea preciso
#que pase el protocolo de seguridad tanto el pasajero como el menor a su cargo.
#Creamos un pasajero turista con otro pasajero turista menor a su cargo y probamos el código







