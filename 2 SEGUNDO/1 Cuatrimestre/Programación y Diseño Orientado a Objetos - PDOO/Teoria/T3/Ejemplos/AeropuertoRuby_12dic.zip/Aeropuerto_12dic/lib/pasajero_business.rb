#encoding: UTF-8
require_relative "pasajero"

class PasajeroBusiness < Pasajero
  attr_reader :numeroTarjetaBusiness
  
  def initialize(pasaporte, numVuelo, tarjeta)
    # Implementa el constructor
  end
  
  def trasladoAlAeropuerto
    puts "Me llevan al aeropuerto"
  end
  
  def dejarCocheEnParking
    #Debe imprimir lo mismo que la superclase y añadir al final: "y además de me lo vigilan"
  end
  
  def accederASalaVip
    puts "Descanso en sala VIP donde tengo acceso a comida y prensa"
  end
  
  def facturar(kgs)
    #Puede facturar el doble de los kgs permitidos
  end
end
