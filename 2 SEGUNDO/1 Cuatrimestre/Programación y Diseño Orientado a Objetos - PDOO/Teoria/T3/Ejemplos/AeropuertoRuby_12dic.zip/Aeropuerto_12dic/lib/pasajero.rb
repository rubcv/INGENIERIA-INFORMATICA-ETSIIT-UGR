

class Pasajero
  
  attr_reader :numVuelo
  
  def initialize(pasaporte, numVuelo)
    @pasaporte = pasaporte
    @numVuelo = numVuelo
    @KILOSPERMITIDOS = 20
  end
  
  def to_s
    "Soy el pasajero con pasaporte #{@pasaporte} del vuelo #{@numVuelo}"
  end
  
  def dejarCocheEnParking
    puts "He dejado el coche en el parking"
  end
  
  def facturar(kgs)
    if(kgs<=@KILOSPERMITIDOS)
      puts "He podido facturar"
    else
      puts "No he podido facturar"
    end
  end
  
  def embarcar
    seguirProtocoloDeSeguridad
    puts "Accedo al vuelo #{@numVuelo}"
  end
  
  private
  def seguirProtocoloDeSeguridad
    puts "Paso el control de seguridad con mi pasaporte (#{@pasaporte})"
  end
  
end
