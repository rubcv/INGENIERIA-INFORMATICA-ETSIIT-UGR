require_relative "pasajero"

class PasajeroTurista < Pasajero
  
  def embarcar
    #Igual que en la superclase pero haciendo cola antes
  end
  
  
  def hacerCola
    puts "Hago cola"
  end
end
