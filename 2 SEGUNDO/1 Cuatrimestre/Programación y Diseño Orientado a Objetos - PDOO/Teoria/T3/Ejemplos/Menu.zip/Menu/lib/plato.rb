require_relative "ingrediente"

class Plato
  
  attr_reader :nombre, :tipo
  
  def initialize(nombre, tipo)
    @nombre = nombre
    @tipo = tipo
    @ingredientes = Array.new
  end
  
  def incluirIngrediente(i)
    @ingredientes << i
  end
  
  def contieneIngrediente(i)
    @ingredientes.contains(i)
  end
  
  def contieneFamiliaDeAlimento(f)
    @ingredientes.each { |ingred| 
      if ingred.familia == f
        return true
      end
    }
    return false
  end
  
  def to_s
    descripcion = "De #{@tipo} tenemos <<#{@nombre}>>, que lleva:"
    for i in 0..@ingredientes.size-2
      descripcion += " "+@ingredientes[i].to_s + ","
    end
    descripcion += " "+@ingredientes[@ingredientes.size-1].to_s + "."
  end
  
end
