#encoding: UTF-8

require_relative "plato"
require_relative "ingrediente"
require_relative "familia_de_alimento"
require_relative "tipo_plato"
require_relative "menu"
require_relative "menu_vegetariano"

#ingredientes
arroz = Ingrediente.new("arroz", FamiliaDeAlimento::CEREAL)
pollo = Ingrediente.new("pollo", FamiliaDeAlimento::CARNE)
conejo = Ingrediente.new("conejo", FamiliaDeAlimento::CARNE)
alubia = Ingrediente.new("alubia", FamiliaDeAlimento::VERDURA)
judia= Ingrediente.new("judía", FamiliaDeAlimento::VERDURA)
tomate = Ingrediente.new("tomate", FamiliaDeAlimento::VERDURA)
ajo = Ingrediente.new("ajo", FamiliaDeAlimento::VERDURA)
garbanzo = Ingrediente.new("garbanzo", FamiliaDeAlimento::LEGUMBRE)
hinojo = Ingrediente.new("hinojo", FamiliaDeAlimento::VERDURA)
yogur = Ingrediente.new("yogur", FamiliaDeAlimento::LACTEO)
berenjena = Ingrediente.new("berenjena", FamiliaDeAlimento::VERDURA)
queso = Ingrediente.new("queso", FamiliaDeAlimento::LACTEO)
manzana = Ingrediente.new("manzana", FamiliaDeAlimento::FRUTA)

#platos
paella = Plato.new("Paella valenciana", TipoPlato::PRIMERO)
paella.incluirIngrediente(arroz)
paella.incluirIngrediente(pollo)
paella.incluirIngrediente(conejo)
paella.incluirIngrediente(alubia)
paella.incluirIngrediente(judia)
paella.incluirIngrediente(tomate)

conejoalajillo = Plato.new("Conejo al ajillo", TipoPlato::PRIMERO)
conejoalajillo.incluirIngrediente(conejo)
conejoalajillo.incluirIngrediente(ajo)

puchero= Plato.new("Puchero vegetariano", TipoPlato::PRIMERO)
puchero.incluirIngrediente(garbanzo)
puchero.incluirIngrediente(hinojo)

berenjenagratinada = Plato.new("Berenjena gratinada", TipoPlato::SEGUNDO)
berenjenagratinada.incluirIngrediente(berenjena)
berenjenagratinada.incluirIngrediente(tomate)
berenjenagratinada.incluirIngrediente(queso)

yogurdemanzana = Plato.new("Yogur", TipoPlato::POSTRE)
yogurdemanzana.incluirIngrediente(yogur)
yogurdemanzana.incluirIngrediente(manzana)

platosDisponibles = [paella, conejoalajillo, puchero, berenjenagratinada, yogurdemanzana]


##### MENÚS

menu = Menu.new(platosDisponibles)
puts menu.to_s

puts "*********************"

menuVegetariano = MenuVegetariano.new(platosDisponibles)
puts menuVegetariano.to_s



