#encoding: UTF-8

require_relative "plato"
require_relative "familia_de_alimento"
require_relative "tipo_plato"

class Menu
  
  def initialize(platosDisponibles)
    @primero = seleccionarPlato(platosDisponibles, TipoPlato::PRIMERO)
    @segundo = seleccionarPlato(platosDisponibles, TipoPlato::SEGUNDO)
    @postre = seleccionarPlato(platosDisponibles, TipoPlato::POSTRE)
  end
  
  def to_s
    "El menú de hoy:\n#{@primero}\n#{@segundo}\n#{@postre}"
  end
  
  def seleccionarPlato(platosDisponibles, tipo)
    platosDisponibles.each{ |plato|
      return plato if plato.tipo == tipo
    }
  end

end
