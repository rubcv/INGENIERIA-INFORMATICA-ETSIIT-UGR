#encoding: UTF-8

require_relative "familia_de_alimento"

class MenuVegetariano < Menu
  
  def to_s
    "Opción Vegetariana\n" + super
  end

  def seleccionarPlato(platosDisponibles, tipo)
    platosDisponibles.each{ |plato|
      return plato if (plato.tipo == tipo && !plato.contieneFamiliaDeAlimento(FamiliaDeAlimento::CARNE) && !plato.contieneFamiliaDeAlimento(FamiliaDeAlimento::PESCADO))
    }
  end
   
end
