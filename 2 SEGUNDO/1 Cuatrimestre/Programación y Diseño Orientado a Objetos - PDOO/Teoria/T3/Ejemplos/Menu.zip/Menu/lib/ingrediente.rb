require_relative "familia_de_alimento"

class Ingrediente
  
  attr_reader :nombre, :familia
  
  def initialize(nombre, familia)
    @nombre = nombre
    @familia = familia
  end
  
  def to_s
    "#{@nombre} (#{@familia})"
  end
  
end
