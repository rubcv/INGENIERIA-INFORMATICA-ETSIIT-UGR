module FamiliaDeAlimento
  LACTEO = :lacteo
  CARNE = :carne
  PESCADO = :pescado
  LEGUMBRE = :legumbre
  CEREAL = :cereal
  VERDURA = :verdura
  FRUTA = :fruta
end
