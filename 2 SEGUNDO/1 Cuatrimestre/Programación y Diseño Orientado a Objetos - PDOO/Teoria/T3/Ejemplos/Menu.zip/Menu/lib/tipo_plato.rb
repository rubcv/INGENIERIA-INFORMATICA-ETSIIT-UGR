module TipoPlato
    PRIMERO = :primero
    SEGUNDO = :segundo
    POSTRE = :postre
end
